package com.example.recyclerjava;

public class Utilidad {
    public static final int LIST=1;
    public static final int GRID=2;
    public static int visualizacion=LIST;




}
